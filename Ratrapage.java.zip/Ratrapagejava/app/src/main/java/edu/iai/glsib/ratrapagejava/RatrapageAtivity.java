package edu.iai.glsib.ratrapagejava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RatrapageAtivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratrapage_ativity);
    }
}